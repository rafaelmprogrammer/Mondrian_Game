using UnityEngine;

public class CollisionAnimation : MonoBehaviour
{
    // Refer�ncia ao Animator do objeto que ser� animado
    public Animator objectAnimator;

    // Tag do objeto com o qual este objeto deve colidir para ativar a anima��o
    public string targetTag = "Player";

    // M�todo chamado quando o Collider 2D deste objeto colide com outro Collider 2D
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Verifica se o objeto colidido tem a tag definida
        if (collision.gameObject.CompareTag(targetTag))
        {
            // Ativa a anima��o definindo um par�metro no Animator
            objectAnimator.SetTrigger("ActivateAnimation");
        }
    }
}

