using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    public Transform player;
    public float offsetY = 2f;

    void Update()
    {
        if (player != null)
        {
            // The position of the camera should follow the moviment of the player in the axis x and y 
            Vector3 newPosition = new Vector3(player.position.x, player.position.y, transform.position.z);
            transform.position = newPosition;
        }
    }
}
