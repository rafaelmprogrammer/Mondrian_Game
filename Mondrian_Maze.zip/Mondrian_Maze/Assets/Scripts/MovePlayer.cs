using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MovePlayer : MonoBehaviour
{
    private Animator anim;
    private Rigidbody2D rb;
    private Vector3 originalScale;
    private float horizontalInput;

    //Put the option in unity to change the speed 
    [SerializeField]
    //speed variable 
    private float speed = 3.0f;

    void Awake()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        originalScale = transform.localScale;
    }

    void Update()
    {
        //Definition of the moviment of the player 
        GetComponent<Rigidbody2D>().velocity = new Vector2 (Input.GetAxis("Horizontal")*speed, Input.GetAxis("Vertical")*speed);

        // Capturar o input horizontal
        horizontalInput = Input.GetAxis("Horizontal");


        // Espelhar o personagem baseado na dire��o da entrada horizontal
        if (horizontalInput > 0)
        {
            transform.localScale = new Vector3(Mathf.Abs(originalScale.x), originalScale.y, originalScale.z);
        }
        else if (horizontalInput < 0)
        {
            transform.localScale = new Vector3(-Mathf.Abs(originalScale.x), originalScale.y, originalScale.z);
        }

        // Definir a anima��o com base no input horizontal
        if (horizontalInput == 0)
        {
            anim.SetBool("IsWalking", false);
        }
        else
        {
            anim.SetBool("IsWalking", true);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Collision with Paint
        if (collision.gameObject.tag == "Paint")
        {
            Destroy(collision.gameObject);
            
        }

        //Collision with finish line
        if (collision.gameObject.tag == "Finish")
        {
            SceneManager.LoadScene(2);
        }
    }



}
